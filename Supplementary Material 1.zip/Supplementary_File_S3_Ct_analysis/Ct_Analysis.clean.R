####################################################################
# Ct analysis

# Load libraries
library(lubridate)
library(dplyr)
library(ggplot2)
library(ggpubr)
library(RColorBrewer)
library(scales)

# Go to dir
path <- "C:/Users/filip/OneDrive/Desktop/LBI/DELTA/REDO/METADATA/"
setwd(path)

# Load data
#df <- read.csv("MG_Ct_data_JulyToSeptember.csv")
df <- read.csv("MG_Ct_data_JulyToSeptember.clean.csv")
head(df)

# Convert specific columns to date
df$Collection_date <- as.Date(df$Collection_date)


df <- df %>% 
  group_by(week=floor_date(Collection_date, "week")) 


####################################################################
# Create time Series plots

# N gene
N<- ggplot(df) +
  geom_boxplot(aes(x=week,y=N,group = week),
               alpha=0.3,width=5) +
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(labels = date_format("%b"),date_breaks = "1 month") +
  ylim(c(0,40)) +
  ylab("Ct - N gene") +
  xlab("Time")
N

# ORF1ab gene
ORF1ab<- ggplot(df) +
  geom_boxplot(aes(x=week,y=ORF1ab,group = week),
               alpha=0.3,width=5) +
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(labels = date_format("%b"),date_breaks = "1 month") +
  ylim(c(0,40)) +
  ylab("Ct - ORF1ab") +
  xlab("Time") 
ORF1ab

# S gene
S <- ggplot(df) +
  geom_boxplot(aes(x=week,y=S,group = week),
               alpha=0.3,width=5) +
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(labels = date_format("%b"),date_breaks = "1 month") +
  ylim(c(0,40)) +
  ylab("Ct - S gene") +
  xlab("Time")
S

# MS2 control
MS2 <- ggplot(df) +
  geom_boxplot(aes(x=week,y=MS2,group = week),
               alpha=0.3,width=5) +
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5)) +
  scale_x_date(labels = date_format("%b"),date_breaks = "1 month") +
  ylim(c(0,40)) +
  ylab("Ct - MS2 control") +
  xlab("Time")
MS2

####################################################################
# Prepare dataset

# Set gamma dataset - 1 July to 7 August
id_gamma_period <- which(df$Collection_date >= dmy(01072021))
df.gamma <- df
id_gamma_period <- which(df.gamma$Collection_date <= dmy(07082021))
df.gamma <- df.gamma[id_gamma_period,]
lineage <- rep("aGamma",length(df.gamma$Collection_date))
df.gamma$lineage <- lineage

# Set Delta dataset - From week 37 onwards
id_delta_period <- which(df$Collection_date >= dmy(12092021))
df.delta <- df[id_delta_period,]
lineage <- rep("Delta",length(df.delta$Collection_date))
df.delta$lineage <- lineage

# Combined dataset
df.comb <- rbind(df.gamma,df.delta)
head(df.comb)

# Set colors
cores <- brewer.pal(n = 11,name = "Spectral")[c(10,2)]


####################################################################
# Create comparison plots and run linear models

# N
p.N <- ggplot(df.comb, aes(x=lineage, y=N, fill=lineage)) +
  geom_violin(trim=FALSE) + 
  geom_boxplot(width=0.25, fill="white") +
  scale_fill_manual(values=cores)+
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5),
        legend.title = element_blank(),
        legend.position = "none") +
  ylim(c(0,40)) +
  xlab("Putative lineage") + 
  ylab("Ct - N gene")
p.N

median(df.comb$N[which(df.comb$lineage=="Gamma")])
median(df.comb$N[which(df.comb$lineage=="Delta")])

m.N <- glm(formula = N ~ lineage,data = df.comb)
summary(m.N)


# ORF1ab
p.ORF1ab <- ggplot(df.comb, aes(x=lineage, y=ORF1ab, fill=lineage)) +
  geom_violin(trim=FALSE) + 
  geom_boxplot(width=0.25, fill="white") +
  scale_fill_manual(values=cores)+
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5),
        legend.title = element_blank(),
        legend.position = "none") +
  ylim(c(0,40)) +
  xlab("Putative lineage") + 
  ylab("Ct - ORF1ab")
p.ORF1ab

median(df.comb$ORF1ab[which(df.comb$lineage=="Gamma")])
median(df.comb$ORF1ab[which(df.comb$lineage=="Delta")])

m.ORF1ab <- glm(formula = ORF1ab ~ lineage,data = df.comb)
summary(m.ORF1ab)


# S
p.S <- ggplot(df.comb, aes(x=lineage, y=S, fill=lineage)) +
  geom_violin(trim=FALSE) + 
  geom_boxplot(width=0.25, fill="white") +
  scale_fill_manual(values=cores)+
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5),
        legend.title = element_blank(),
        legend.position = "none") +
  ylim(c(0,40)) +
  xlab("Putative lineage") + 
  ylab("Ct - S gene")
p.S

median(df.comb$S[which(df.comb$lineage=="Gamma")])
median(df.comb$S[which(df.comb$lineage=="Delta")])

m.S <- glm(formula = S ~ lineage,data = df.comb)
summary(m.S)

# MS2 control
p.MS2 <- ggplot(df.comb, aes(x=lineage, y=MS2, fill=lineage)) +
  geom_violin(trim=FALSE) + 
  geom_boxplot(width=0.25, fill="white") +
  scale_fill_manual(values=cores)+
  theme_classic() + 
  theme(plot.title = element_text(hjust = 0.5),
        legend.title = element_blank(),
        legend.position = "none") +
  ylim(c(0,40)) +
  xlab("Putative lineage") + 
  ylab("Ct - MS2 control")
p.MS2

median(df.comb$MS2[which(df.comb$lineage=="Gamma")])
median(df.comb$MS2[which(df.comb$lineage=="Delta")])

m.MS2 <- glm(formula = MS2 ~ lineage,data = df.comb)
summary(m.MS2)

####################################################################
# Write model results to a file
sink("Results_models_Gamma-Delta-periods.txt")
summary(m.N)
summary(m.ORF1ab)
summary(m.S)
summary(m.MS2)
sink()

# Plot 
panel_alternative <- ggarrange(N,p.N,ORF1ab,p.ORF1ab,S,p.S,MS2,p.MS2,
                               labels = c("A","B","C","D","E","F","G","H"),
                               nrow = 4,ncol = 2)

# It is further edited manually
panel_alternative
